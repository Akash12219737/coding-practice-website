function myfun1() {
  window.location.href = "index.html";
}

function myfun2() {
  window.location.href = "aboutus.html";
}
function myfun3() {
  window.location.href = "joinus.html";
}
function myfun4() {
  window.location.href = "contact.html";
}
function exercise(n) {
  if (n == 1) window.location.href = "chest.html";
  if (n == 2) window.location.href = "back.html";
  if (n == 3) window.location.href = "arms.html";
  if (n == 4) window.location.href = "abs.html";
  if (n == 5) window.location.href = "legs.html";
  if (n == 6) window.location.href = "shoulders.html";
  if (n == 7) window.location.href = "diet.html";
}
